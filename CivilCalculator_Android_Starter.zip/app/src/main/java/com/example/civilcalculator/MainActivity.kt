package com.example.civilcalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity: ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { App() } }
}

@Composable fun App() {
    var page by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme=lightColorScheme(primary=Color(0xFF174A7E), secondary=Color(0xFF2E7D32))) {
        Scaffold(topBar={TopAppBar(title={Text("Civil Calculator")})}) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(page) {
                    "Home" -> Home { page=it }
                    "Unit Converter" -> UnitConverter()
                    "Construction" -> Construction()
                    "Surveying" -> Surveying()
                    "Formulas" -> Formulas()
                    "Notes" -> Notes()
                    "MCQ Practice" -> MCQ()
                    else -> Percentage()
                }
            }
        }
    }
}

@Composable fun Home(open:(String)->Unit) {
    val items=listOf(
        "📐  Unit Converter" to "Length, area, volume & mass",
        "🧱  Construction" to "Concrete & construction calculators",
        "📏  Surveying" to "Slope, gradient & basic calculations",
        "⚖️  Engineering Formulas" to "Quick civil formulas",
        "📚  Important Notes" to "Student quick-reference notes",
        "📝  MCQ Practice" to "Practice civil engineering MCQs",
        "📊  Percentage / GPA" to "Marks and percentage calculator"
    )
    LazyColumn(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("Civil Engineering Student Toolkit", style=MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(12.dp)) }
        items(items) { (title,sub) ->
            ElevatedCard(onClick={open(title.substring(4))}, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) { Text(title, style=MaterialTheme.typography.titleMedium); Text(sub) }
            }
        }
    }
}

@Composable fun Field(label:String,v:String,set:(String)->Unit)=>
    OutlinedTextField(v,set,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth())

@Composable fun UnitConverter() {
    var v by remember{mutableStateOf("")}; var out by remember{mutableStateOf("")}
    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Length Converter",style=MaterialTheme.typography.titleLarge); Field("Metres",v){v=it}
        Button({out=v.toDoubleOrNull()?.let{"cm=${it*100}\nmm=${it*1000}\nfeet=${it*3.28084}\ninches=${it*39.3701}"}?:"Enter a valid number"}){Text("Convert")}
        Text(out)
    }
}

@Composable fun Construction() {
    var l by remember{mutableStateOf("")}; var b by remember{mutableStateOf("")}; var h by remember{mutableStateOf("")}; var out by remember{mutableStateOf("")}
    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Concrete Volume",style=MaterialTheme.typography.titleLarge); Text("Enter dimensions in metres.")
        Field("Length",l){l=it}; Field("Width",b){b=it}; Field("Depth / Height",h){h=it}
        Button({val a=l.toDoubleOrNull();val c=b.toDoubleOrNull();val d=h.toDoubleOrNull();out=if(a!=null&&c!=null&&d!=null)"Volume = %.3f m³".format(a*c*d) else "Enter all dimensions"}){Text("Calculate")}
        Text(out); Text("Formula: Volume = L × B × H")
    }
}

@Composable fun Surveying() {
    var rise by remember{mutableStateOf("")};var run by remember{mutableStateOf("")};var out by remember{mutableStateOf("")}
    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Slope / Gradient",style=MaterialTheme.typography.titleLarge);Field("Rise",rise){rise=it};Field("Run",run){run=it}
        Button({val a=rise.toDoubleOrNull();val b=run.toDoubleOrNull();out=if(a!=null&&b!=null&&b!=0.0)"Gradient = ${a/b}\nSlope = ${(a/b)*100}%" else "Enter valid values"}){Text("Calculate")}
        Text(out)
    }
}

@Composable fun Formulas() {
    val x=listOf("Rectangle area = L × B","Rectangle volume = L × B × H","Triangle area = ½ × base × height","Circle area = πr²","Density = Mass / Volume","Stress = Force / Area","Strain = Change in length / Original length","Discharge Q = A × V")
    LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(x){Text("• $it")}}
}

@Composable fun Notes() {
    val x=listOf("Concrete = cement + fine aggregate + coarse aggregate + water.","Slump test assesses workability of fresh concrete.","Curing helps concrete gain strength.","Compaction reduces air voids in fresh concrete.","Surveying determines relative positions of points.")
    LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(x){ElevatedCard{Text(it,Modifier.padding(16.dp))}}}
}

@Composable fun MCQ() {
    var ans by remember{mutableStateOf("")}; val opts=listOf("Slump test","CBR test","Impact test","Los Angeles test")
    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("Which test commonly measures workability of fresh concrete?",style=MaterialTheme.typography.titleMedium)
        opts.forEach{OutlinedButton({ans=it},Modifier.fillMaxWidth()){Text(it)}}
        if(ans.isNotEmpty())Text(if(ans=="Slump test")"Correct! ✅" else "Incorrect. Correct answer: Slump test")
    }
}

@Composable fun Percentage() {
    var a by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var out by remember{mutableStateOf("")}
    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Percentage Calculator",style=MaterialTheme.typography.titleLarge);Field("Marks obtained",a){a=it};Field("Total marks",b){b=it}
        Button({val x=a.toDoubleOrNull();val y=b.toDoubleOrNull();out=if(x!=null&&y!=null&&y!=0.0)"Percentage = %.2f%%".format(x/y*100) else "Enter valid marks"}){Text("Calculate")}
        Text(out);Text("GPA conversion should use your college's official grading scale.")
    }
}
